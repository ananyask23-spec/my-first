/*Name: Ananya S K
  Date: 08/07/2025
  Description: Addressbook
*/

//heder file which include some scanf , printf, fprintf, fscanf functions....
#include<stdio.h>
//header file which include the chracter is digit or lower ....
#include<ctype.h>
//header file which include compare, copy, string length operations....
#include<string.h>
//heder file which include exit function 
#include<stdlib.h>

//structure contains the following contact information 
struct Contact_data
{
    char name[20];
    char mobilenumber[25];
    char mailid[25];
};
//structure to store 100 users contact details
struct Addressbook
{
    struct Contact_data contactlist[100];
    int contact_count;

}; 
//function declaration for all specific functions
  void Create_contact(struct Addressbook *ptr);
  int validmobilenumber(char *mobilenumber);
  int validmailid(char *id);
  void List_contact(struct Addressbook *ptr1);
  int  Search_contact(struct Addressbook *ptr2);
  int search_by_name(struct Addressbook *ptr3);
  int search_by_mobilenumber(struct Addressbook *ptr4);
  int search_by_mailid(struct Addressbook *ptr5);
  void Delete_contact(struct Addressbook *ptr6);
  void Edit_contact(struct Addressbook *ptr7);
  void Save_contact_and_exit(struct Addressbook *ptr8);
  void load_contact(struct Addressbook *ptr9);

  //main function
  int main()
{
    
    struct Addressbook var={ .contact_count = 0 };//contact count is initialized to zero
    load_contact(&var);
  
    int op;
    do
    {
printf("\nwelcome to main menu\n");

//main menu to show the feautures of addressbook 
printf("1. Create contact\n2. List Contact\n3. Search contact\n4. Delete contact\n5. Edit contact\n6. Save contact and exit\n7. Exit contact");

printf("\nenter your choice: ");
scanf("%d", &op);
getchar();
switch(op)
        {
  case 1:
  Create_contact(&var);
  break;
  
  case 2:
  List_contact(&var);
  break;
  
   case 3:
   Search_contact(&var);
  break;
  
  case 4:
  Delete_contact(&var);
  break;
  
  case 5:
  Edit_contact(&var);
  break;
  
  case 6:
  Save_contact_and_exit(&var);
  break;

  case 7:
  //successfully exit from addressbook
  exit(0);
  break;
  
  default:
  printf("invalid");
  
  }
        }
while(op!=7);
    }

//load contact to restore contact details from file back to structure memory
void load_contact(struct Addressbook *ptr9)
{
    FILE *fp;//creating file pointer
    fp=fopen("contacts.csv", "r");//opening csv file in read mode
    if(fp==NULL)
    {
        printf("error");//checking error
    }
    fscanf(fp, "%d\n", &ptr9->contact_count);//read from the file
    for(int i=0;i<ptr9->contact_count;i++)
    {
        fscanf(fp, "%[^,],%[^,],%[^\n]\n", ptr9->contactlist[i].name, ptr9->contactlist[i].mobilenumber, ptr9->contactlist[i].mailid);
    }
    fclose(fp);//close the file
}

//save contact to store the contact details permanently through contacts.csv file
void Save_contact_and_exit(struct Addressbook *ptr8)   
{   
    if(ptr8->contact_count==0)
    {
        printf("no contacts available to save");
        return;
    }
    FILE *fp;
    fp=fopen("contacts.csv", "w");//open file in writing mode
    if(fp==NULL)
    {
    printf("error");//checking any error present
    }

    fprintf(fp, "%d\n", ptr8->contact_count);//write to the file
    for(int i=0;i<ptr8->contact_count;i++)
    {
    fprintf(fp, "%s,%s,%s\n", ptr8->contactlist[i].name, ptr8->contactlist[i].mobilenumber, ptr8->contactlist[i].mailid);
    }

    printf("saved succesfully");
    fclose(fp);//close the file
    exit(0);
}
//function to edit the contacts
void Edit_contact(struct Addressbook *ptr7)
{
    if(ptr7->contact_count==0)
    {
    printf("no contacts available to edit");
    return;
    }
    int choice;
    //menu to edit the contacts
    printf("enter edit by\n1. name\n2. mobile number\n3. mailid\n");
    scanf("%d", &choice);
    getchar();

    char input[20];
    //creating array to store the contact details containing same name or same mail id
    int indexes[100];
    int found_count = 0;
    

    switch(choice)
    {case 1:
        printf("enter name: ");
        scanf("%[^\n]", input);
        getchar();
        break;
        
        
        case 2:
        do
        {
            printf("Enter mobile number: ");
            scanf("%[^\n]", input);
            getchar();
            if (!validmobilenumber(input))//validate the mobile number
                printf("Invalid mobile number. Try again.\n");
        } while (!validmobilenumber(input));
        break;

         case 3:
        do
        {
            printf("Enter mail ID: ");
            scanf("%[^\n]", input);
            getchar();
            if (!validmailid(input))//validate the mail id
                printf("Invalid mail ID. Try again.\n");
        } while (!validmailid(input));
        break;
    default:
        printf("Invalid choice.\n");
        return;
    }

    for(int i=0;i<ptr7->contact_count;i++)
    {
        int found=0;
        //compare the  name input with saved one
        if(choice==1&&strcmp(ptr7->contactlist[i].name, input)==0)
        found=1;
        
        //compare the  mobile number input with saved one
        else if(choice==2&&strcmp(ptr7->contactlist[i].mobilenumber, input)==0)
        found=1;
        
        //compare the  mail id input with saved one
        else if(choice==3&&strcmp(ptr7->contactlist[i].mailid, input)==0)
        found=1;
    
        if(found)
        {
            if(found_count==0)
            {
printf("------------------------------------------------------------------\n");
printf("| %-3s | %-15s | %-15s | %-30s\n", "NO", "NAME", "MOBILE_NUMBER", "MAIL_ID");
printf("------------------------------------------------------------------\n");
            }
//storing the index value in the array if contact is found
indexes[found_count]=i;

//print the contact details
printf("------------------------------------------------------------------\n");
printf("| %-3d | %-15s | %-15s | %-30s\n", found_count + 1,ptr7->contactlist[i].name, ptr7->contactlist[i].mobilenumber,ptr7->contactlist[i].mailid);
found_count++;
        }
    }
            
if(found_count==0)
{
printf("no matching contact found");
return ;
}

int user_choice;
//if only one contact found 
if(found_count==1)
{
    user_choice=indexes[0];
}

else
{
    //if multiple contacts found
printf("Multiple contacts found\nenter the index(1 to %d) to edit:", found_count);
scanf("%d", &user_choice);
while(user_choice<1||user_choice>found_count)//validate userchoice
{
    printf("Enter the valid index (1 to %d) to delete:", found_count);
    scanf("%d", &user_choice); 
}
user_choice=indexes[user_choice-1];
}

//again show menu to edit the contact details on specific field

    int edit_choice;
    printf("\nWhat do you want to edit?\n1. Name\n2. Mobile Number\n3. Mail ID\nEnter your choice: ");
    scanf("%d", &edit_choice);
    getchar();

    char newdata[25];

    switch (edit_choice)
     {
    case 1:
        printf("Enter new name: ");
        scanf("%[^\n]", newdata);
        //copy the newdata to saved one in particular field of name
        strcpy(ptr7->contactlist[user_choice].name, newdata);
        break;

    case 2:
    int duplicate;
        do
   {
    //mobile number
    duplicate=0;
    printf("Enter your number: ");
    scanf("%[^\n]",newdata);
    getchar();
    if(!validmobilenumber(newdata))
    {
       printf("invalid number\n");
       continue;//go back to loop
    }
    //check for duplicates
    
    for (int i = 0; i < ptr7->contact_count; i++) 
    {
        if (strcmp(ptr7->contactlist[i].mobilenumber, newdata) == 0)
         {
            duplicate=1;//duplicate found
            printf("contact already exist\n");
            break;

          }
    }
    }
  while(!validmobilenumber(newdata)||duplicate!=0);//validating mobilenumber along with duplicate
  break;
  

    case 3:
        do 
        {
            printf("Enter new mail ID: ");
            scanf("%[^\n]", newdata);
            getchar();
        } while (!validmailid(newdata));
        //copy the newdata to saved one in particular field of mailid
        strcpy(ptr7->contactlist[user_choice].mailid, newdata);
        break;
    default:
        printf("Invalid edit option.\n");
        return;
    }

    printf("Contact updated successfully.\n");
}
        

// Delete contact 
void Delete_contact(struct Addressbook *ptr6)
{
  
    if (ptr6->contact_count == 0)
    {
        printf("No contacts available to delete.\n");
        return;
    }

    int choice;
    //menu to delete contacts 
    printf("Delete contact by:\n1. Name\n2. Mobile Number\n3. Mail ID\nEnter your choice: ");
    scanf("%d", &choice);
    getchar(); 

    char input[25];
    //creating array to store the contact details containing same name or same mail id.
    int indexes[100];
    int found_count = 0;

    
    switch (choice)
    {
    case 1:
        printf("Enter name: ");
        scanf("%[^\n]", input);
        break;
    case 2:
        do
        {
            printf("Enter mobile number: ");
            scanf("%[^\n]", input);
            getchar();
            if (!validmobilenumber(input))//validate the  mobilenumber input
                printf("Invalid mobile number. Try again.\n");
        } while (!validmobilenumber(input));
        break;
    case 3:
        do
        {
            printf("Enter mail ID: ");
            scanf("%[^\n]", input);
            getchar();
            if (!validmailid(input))//validate the  mailid input
                printf("Invalid mail ID. Try again.\n");
        } while (!validmailid(input));
        break;
    default:
        printf("Invalid choice.\n");
        return;
    }

    
    for (int i = 0; i < ptr6->contact_count; i++)//run loop till contact count
    {
        int found = 0;
        //compare the  name input with saved one
        if (choice == 1 && strcmp(ptr6->contactlist[i].name, input) == 0)
            found = 1;
        //compare the  mobilenumber input with saved one
        else if (choice == 2 && strcmp(ptr6->contactlist[i].mobilenumber, input) == 0)
            found = 1;
        //compare the new mailid input with saved one
        else if (choice == 3 && strcmp(ptr6->contactlist[i].mailid, input) == 0)
            found = 1;
           

        if (found)
        {
            if (found_count == 0)
            {
printf("------------------------------------------------------------------\n");
printf("| %-3s | %-15s | %-15s | %-30s\n", "NO", "NAME", "MOBILE_NUMBER", "MAIL_ID");
printf("------------------------------------------------------------------\n");
            }
//storing the index value in the array if contact is found
indexes[found_count] = i;
printf("------------------------------------------------------------------\n");
printf("| %-3d | %-15s | %-15s | %-30s\n", found_count + 1,ptr6->contactlist[i].name, ptr6->contactlist[i].mobilenumber,ptr6->contactlist[i].mailid);
            found_count++;
        
       }
   }

    if (found_count == 0)
    {
        printf("No matching contact found.\n");
        return;
    }

    int user_choice;
    //if only one contact found
    if (found_count == 1)
    {
        user_choice= indexes[0]; 
    }
    else
    {
        //if more than one contacts found
        
        printf("Multiple contacts found. Enter the index (1 to %d) to delete: ", found_count);
        scanf("%d", &user_choice);
        while(user_choice < 1 || user_choice> found_count)//validate userchoice
        {
            printf("Invalid selection.\n");
            printf("Enter the valid index (1 to %d) to edit:", found_count);
            scanf("%d", &user_choice);
            
        }
        user_choice= indexes[user_choice - 1];
    }

    // Shift contacts to delete
    for (int i = user_choice; i < ptr6->contact_count - 1; i++)
    {
        ptr6->contactlist[i] = ptr6->contactlist[i + 1];
    }
    ptr6->contact_count--;//decreement contact count after each deletion

    printf("Contact deleted successfully.\n");
}



// function to search contacts by mailid
int search_by_mailid(struct Addressbook *ptr5)
{
char mailid[20];
do
   {
    printf("Enter your mailid: ");
    getchar();
    scanf("%[^\n]", mailid);
    
    if(!validmailid(mailid))//validating mailid
    {
      printf("invalid mailid\n");
    }
  }while(!validmailid(mailid));
int found_count=0;
for(int i=0;i<ptr5->contact_count;i++)
{
    //comparing whether searched mailid is matches to mailid created  in contact list   
if(strcmp(ptr5->contactlist[i].mailid, mailid)==0)
{
  if(found_count==0)
  {

printf("CONTACT FOUND\n");
printf("------------------------------------------------------------------\n");
printf("| %-3s | %-15s | %-15s | %-30s\n", "NO", "NAME", "MOBILE_NUMBER", "MAIL_ID");
printf("------------------------------------------------------------------\n");
  }
// print the contact details if found
printf("------------------------------------------------------------------\n");
printf("| %-3d | %-15s | %-15s | %-30s\n", i+1, ptr5->contactlist[i].name, ptr5->contactlist[i].mobilenumber,ptr5->contactlist[i].mailid);
found_count=1;//if matches found set to 1;

//return index value.
}
}

if(!found_count)
{
printf("contact not found");
return -1;
}
}
//function to search contacts  by mobile number
int search_by_mobilenumber(struct Addressbook *ptr4)
{
char mobilenumber[20];

do
{

printf("enter mobile_number to be searched: ");
getchar();
scanf("%[^\n]", mobilenumber);
if(!validmobilenumber(mobilenumber))//validating mobile number
    {
       printf("invalid number\n");
    }
  }while(!validmobilenumber(mobilenumber));
  int found=0;
for(int i=0;i<ptr4->contact_count;i++)
{
 //comparing whether searched mobilenumber is matches to mobilenumber created  in contact list   
if(strcmp(ptr4->contactlist[i].mobilenumber, mobilenumber)==0)
{
  if(found==0)
{

printf("CONTACT FOUND\n");
printf("------------------------------------------------------------------\n");
printf("| %-3s | %-15s | %-15s | %-30s\n", "NO", "NAME", "MOBILE_NUMBER", "MAIL_ID");
printf("------------------------------------------------------------------\n");
}

// print the contact details if found
printf("------------------------------------------------------------------\n");
printf("| %-3d | %-15s | %-15s | %-30s\n", i+1, ptr4->contactlist[i].name, ptr4->contactlist[i].mobilenumber,ptr4->contactlist[i].mailid);
found=1;//if matches found set to 1;

}
}
if(found==0)
printf("contact not found");

}

// function to search contacts by name
int search_by_name(struct Addressbook *ptr3)
{
    char name[20];
    int found_count = 0;

    printf("Enter name to be searched: ");
    getchar();
    scanf("%[^\n]", name);

    for (int i = 0; i < ptr3->contact_count; i++)
    {
        //comparing whether searched name is matches to name created  in contact list
        if (strcmp(ptr3->contactlist[i].name, name) == 0)
        {
            if (found_count == 0)
            {
                printf("CONTACT(S) FOUND:\n");
                printf("------------------------------------------------------------------\n");
                printf("| %-3s | %-15s | %-15s | %-30s\n", "NO", "NAME", "MOBILE_NUMBER", "MAIL_ID");
            }
            // print the contact details if found
            printf("------------------------------------------------------------------\n");
            printf("| %-3d | %-15s | %-15s | %-30s\n", i + 1,
                   ptr3->contactlist[i].name,
                   ptr3->contactlist[i].mobilenumber,
                   ptr3->contactlist[i].mailid);
                   found_count=1;//if matches found set to 1;
            }
          }

            
     if(!found_count)
     {
    printf("contact not found\n");
    return -1;
     }
}


// function to search contact
int Search_contact(struct Addressbook *ptr2)
{
   printf("search contacts by\n1. name\n2. mobilenumber\n3. mailid\n");
   int choice;
   printf("enter choice: ");
   scanf("%d", &choice);
   //choices to search the contacts based on name, mobile number , mail id
   switch(choice)
   {
   case 1:
   return search_by_name(ptr2);
   break;
   case 2:
   return search_by_mobilenumber(ptr2);
   break;
   case 3:
   return search_by_mailid(ptr2);
   break;
   default:
   printf("invalid input");
   return -1;
}
}
// function to list the contacts
void List_contact(struct Addressbook *ptr1)
{
  if(ptr1->contact_count==0)//if no contact created
  {
printf(" No contact created");

  }
else
{
//print the contact details if found
  printf("SAVED CONTACT:\n");
  printf("------------------------------------------------------------------\n");
  printf("| %-3s | %-15s | %-15s | %-30s\n", "NO", "NAME", "MOBILE_NUMBER", "MAIL_ID");
  printf("------------------------------------------------------------------\n");
  for(int i=0;i<ptr1->contact_count;i++)
  {
  printf("------------------------------------------------------------------\n");
  printf("| %-3d | %-15s | %-15s | %-30s\n", i+1, ptr1->contactlist[i].name, ptr1->contactlist[i].mobilenumber,ptr1->contactlist[i].mailid);
  
  }
}
}

// function to validate mobile number
int validmobilenumber(char*mobilenumber)
{
    //check number contains only 10 characters or not
    if(strlen(mobilenumber)!=10)
    return 0;
    for(int i=0;i!=10;i++)
    {
        if(!isdigit(mobilenumber[i]))//checking whether characters are digit nnot
        return 0;
    }
    return 1;//passed check
    }
    
    // function validate mailid
    int validmailid(char *id)
    {
     int len=strlen(id);
     int count=0;
     for(int i=0;i<len;i++)
     {
     char c=id[i];
     //checking whether mail id consist of only lower case alphabets, digits , @ and . character
     if(!islower(c)&&!isdigit(c)&&c!='@'&&c!='.')
     return 0;
     
     //checking first character itself @
     if(id[0]=='@')
     return 0;
     
     if(c=='.'&&i>0&&id[i-1]=='@')//if @ follows immediate back of .
     return 0;

     //check mail contains only one @ or more
     if(c=='@')
     count++;
     }
     if(count!=1)
     return 0;
     
     char*at_p1=strchr(id,'@');
     char*dot_p2=strstr(id, ".com");
     
     //check the presence of @ and string ".com"
     if ((dot_p2 == NULL)||(at_p1==NULL))
     return 0;
     
     //check . came after @ or not
     if (dot_p2 < at_p1)
     return 0;
    
     //check last 4 characters are .com or not
    if (len < 4 || id[len - 4] != '.' || id[len - 3] != 'c' || id[len - 2] != 'o' || id[len - 1] != 'm')
    return 0;


    //check after .com, no other characters sholud present
    if(strlen(dot_p2+4)>0)
    return 0;
    
    
     
     return 1;//passed all check
    }

// function to create the contacts
void Create_contact(struct Addressbook *ptr)
{
   char name[20];
   char mobilenumber[20];
   char mailid[20];
   
   //name 
   int duplicate;
   printf("enter your name: ");
   scanf("%[^\n]", name);
   getchar();
   do
   {
    //mobile number
    duplicate=0;
    printf("Enter your number: ");
    scanf("%[^\n]",mobilenumber);
    getchar();
    if(!validmobilenumber(mobilenumber))
    {
       printf("invalid number\n");
       continue;//go back to loop
    }
    //check for duplicates
    
    for (int i = 0; i < ptr->contact_count; i++) 
    {
        if (strcmp(ptr->contactlist[i].mobilenumber, mobilenumber) == 0)
         {
            duplicate=1;//duplicate found
            printf("contact already exist\n");
            break;

          }
    }
    }
  while(!validmobilenumber(mobilenumber)||duplicate!=0);//validating mobilenumber along with duplicate
  
  do
   {
    printf("Enter your mailid: ");
    scanf("%[^\n]", mailid);
    getchar();
    if(!validmailid(mailid))//validating  entered mailid
    {
      printf("invalid mailid\n");
    }
  }while(!validmailid(mailid));
   

printf("Contact saved Succesfully");

strcpy(ptr->contactlist[ptr->contact_count].name, name);//copy name to contactlist
strcpy(ptr->contactlist[ptr->contact_count].mobilenumber, mobilenumber);//copy mobile number contact list
strcpy(ptr->contactlist[ptr->contact_count].mailid, mailid);//copy maild id to contactlist
ptr->contact_count++;// increasing contact count after creating each contact
}




    
   
   
    
    
    
   
    



    

    






